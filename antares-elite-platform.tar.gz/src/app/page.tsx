import EliteControlCenter from '../../components/dashboard/EliteControlCenter';

export default function Home() {
  return (
    <main className="min-h-screen">
      <EliteControlCenter />
    </main>
  );
}
